# PCI / Peer Community Journal submission checklist (paper 01)

Route: preprint with DOI -> thematic PCI (e.g. Neuroscience, Health and Movement Sciences, or Statistics and Machine Learning) -> after recommendation, format for PCJ and transfer. PCJ cannot be submitted to directly.

| Requirement | Status |
|---|---|
| Preprint deposited (bioRxiv/OSF/Zenodo/arXiv) with DOI | **Not done** - `papers/01_*.pdf` is the preprint-ready version (title page, abstract) |
| Data available with DOI | Done - OpenNeuro ds006840 v1.0.0 (CC0) |
| Code/scripts with permanent identifier (Zenodo DOI or SWHID; Git URLs are not permanent) | Done - doi:10.5281/zenodo.24234427 (confirm the record contains `src/audit_event_tables.py`, `src/lopo_outcome_baselines.py`, `reports/audit` and `papers/`; if not, tag a new release after pushing the branch) |
| README describing scripts and how to run them | Partly - README has run order; add expected outputs per script |
| Scripts reproduce the article's numbers | Done for audit/baselines from the released event tables (seeded); not applicable to EEG results (none) |
| Sample size justification | Done - "Sample size justification" subsection (secondary analysis, fixed N = 15, precision reported) |
| Experimental procedures in text | Partly - task described from the descriptor; verify against the descriptor before submission |
| Ethics statement | Done - Ethics Committee of the First Hospital of Qinhuangdao, approval 2024G006, written consent, de-identified data (as stated in the original article) |
| AI-use disclosure (text, code) and human verification | Done - author ran all analyses |
| No AI-generated illustrations | Met - figures are plotted from data by scripts |
| Funding / conflict of interest (no financial COI allowed) | Done - no funding; no non-financial conflicts declared (add a financial-COI statement if PCI's form asks) |
| Mandatory closing sections | Present: availability, acknowledgements, funding, COI, references |
| No cover page, header, footer, line/page numbers; 2.54 cm margins; PNG figures | Met in `papers/pcj/*.docx` |
| APA 7 references with DOIs; BibTeX of cited references only | Done - `manuscript/references_pcj.bib` (4 entries; code DOI pending) |
| Acknowledgement sentence naming PCI recommendation | Left blank until recommendation; add then |
| Picture for the article page (own rights) | **Not done** |
| Author affiliation on title page | **Check** - preprint byline says "Nnamdi Azikiwe University, Awka, Nigeria - Computational Neuroscience Research"; confirm wording |

Scientific content to settle before submission: run the EEG models on the downloaded derivatives (the article currently reports audit and outcome baselines only), reconcile 6,671 vs 6,720 from `keep_mask_1s`, and verify the movement-onset definition against Leap kinematics.
