# Pre-movement EEG and Subsequent Action Kinematics: A Participant-Independent Modelling Protocol with Data Audit and Outcome Baselines

**Author:** Ekemini Thompson  
**Affiliation:** Nnamdi Azikiwe University, Awka, Nigeria · Computational Neuroscience Research  
**Status:** Protocol and data-audit manuscript · Dataset: IACKD, OpenNeuro ds006840

## Abstract

Movement preparation and execution are linked processes, but whether neural activity immediately preceding an action predicts its subsequent kinematic expression in unseen individuals remains an empirical question. This manuscript specifies a participant-independent analysis of the IACKD dataset (OpenNeuro ds006840), which combines 1,024 Hz EEG and 170 Hz three-dimensional hand kinematics, and reports a file-level audit of the released data together with outcome-side baselines. The audit covers 15 participants, 128 runs, 14.8 hours of recording and 7,029 trials with a consistent structure of a 1 s pre-movement event followed by an execution event. Every run has a complete event table, a channel table and an EEG recording; the released EEG contains 26 channels for 11 participants and 28 for four. Execution duration, the outcome available at trial level, varies strongly between participants (intraclass correlation 0.74). Under leave-one-participant-out evaluation the training-fold mean predictor reaches a mean absolute error of 0.91 s (participant-clustered 95% CI [0.67, 1.22]), and task covariates alone do not improve on it. A trial-wise random split that knows only participant identity halves the error (0.43 s versus 0.82 s), quantifying the inflation that participant-held-out validation prevents. These results fix the benchmark that pre-movement EEG models must exceed and define the common channel set, trial accounting and sensitivity analyses for the modelling stage. The study does not treat instructed congruent/incongruent mapping conditions as unexpected perturbations and does not claim to measure consciousness or sense of agency.

**Keywords:** EEG; hand kinematics; movement preparation; participant-independent validation; multimodal modelling; reproducibility; leave-one-participant-out.

## 1. Background and Rationale

Multimodal recordings that combine neural activity and movement trajectories provide an opportunity to examine relationships between pre-action brain signals and subsequent movement behaviour. Predictive analyses must account for repeated observations within individuals. If trials from one participant appear in both training and test partitions, performance may reflect participant-specific information rather than generalisation to a new person. This manuscript therefore places participant-independent evaluation at the centre of the analysis and quantifies, on the released data, why that choice matters.

## 2. Aim and Research Question

The primary research question is whether features extracted from EEG recorded strictly before movement onset can predict prespecified continuous kinematic properties of the subsequent action in a participant excluded entirely from model fitting. The estimand is participant-held-out predictive performance on valid, matched trials. It is not a causal effect of neural activity on movement, nor a measure of conscious access or sense of agency.

The aims of the work reported here are (i) to audit the released dataset at file and event level, (ii) to establish the trial accounting and channel set on which modelling will rest, and (iii) to determine the participant-independent performance of outcome-side baselines that any EEG-based model must exceed.

## 3. Dataset and Provenance

The dataset is OpenNeuro accession ds006840 (DOI: 10.18112/openneuro.ds006840.v1.0.0), released under CC0 and described in a Scientific Data descriptor (DOI: 10.1038/s41597-026-07146-x). Participants steered an on-screen ball to a boundary with one hand, under a congruent (red cue) or incongruent (yellow cue) mapping between hand and ball direction, with each trial comprising a one-second pre-movement period followed by execution. The congruent and incongruent conditions are instructed visuomotor mapping conditions and are not unexpected perturbations. The dataset does not provide subjective reports of consciousness, conscious access or sense of agency. Table 1 sets the published properties beside those found in the released files.

**Table 1. Dataset properties: published descriptor and README versus the released BIDS files.**

| Property | Descriptor / README | Released files (this audit) |
|---|---|---|
| Participants | 15 | 15 |
| Runs | — | 128 (8 per participant; 12 for sub-04 and sub-05) |
| EEG sampling rate | 1,024 Hz | 1,024 Hz in all 128 sidecars |
| EEG channels | 32 | 26 EEG (11 participants) or 28 EEG (sub-02, 13, 14, 15), plus VEOG, HEOG and Trigger |
| Kinematics sampling rate | 170 Hz | 170 Hz in all 128 sidecars |
| Recording time | — | 14.8 h (median run 416 s) |
| Recorded trials | 7,040 | 7,029 premove-anchored trials in event tables |
| Valid trials | 6,671 (descriptor); 6,720 (README) | 6,864 trials with execution duration > 0 s (event-level criterion) |

## 4. Feasibility and Data Audit Methods

The audit was run on the released BIDS dataset (version 1.0.0) with a scripted inventory (src/audit_event_tables.py). It records, for every run, the event-table structure, channel table, sidecar metadata and file sizes, and builds a trial-matching table with participant, run, hand, condition, pre-movement onset and duration, execution onset and duration, and hit event. A trial is anchored on its premove event and linked to the execution and hit events that follow it. Channel counts and recording durations were read from the channel tables and sidecars, and raw EEG file sizes were compared with the size expected from the channel count, 4-byte samples, 1,024 Hz and the recorded duration. Filename similarity is not used as evidence of trial correspondence.

The outcome-side baselines use execution-event duration, the trial-level outcome available from the event tables. Two models are fitted under leave-one-participant-out evaluation: the training-fold mean predictor, and a ridge regression on task covariates (congruency, target direction, hand and in-run trial position) whose penalty is selected by leave-one-training-participant-out validation inside each training fold. Nothing is fitted, scaled or tuned using the held-out participant. Fold results are summarised as the mean over held-out participants, with 95% confidence intervals from a participant-level cluster bootstrap (10,000 resamples, seed 20261114). The primary analysis set (execution duration above zero) and the sensitivity sets (all trials with an execution event; the primary set without sub-04) were defined after inspecting the event tables and are reported with that status. The trial-wise comparison splits the primary set at random into 80% training and 20% test and predicts each test trial with its participant's training mean.

## 5. Planned Modelling and Validation

The primary candidate task is regression from pre-movement EEG features to continuous kinematic outcomes selected before model comparison. The outer evaluation loop is leave-one-participant-out (Figure 1). All trials from the held-out participant remain outside preprocessing fitting, feature selection, dimensionality reduction, hyperparameter selection and calibration, and inner model selection uses participant-grouped partitions. A training-fold mean predictor and regularised linear regression form the initial baselines; more complex models are secondary and must show added value under the same participant-held-out splits. For continuous outcomes the metrics are mean absolute error (MAE) and root mean squared error (RMSE), with participant-level fold results reported and uncertainty estimated by resampling participants.

![Figure 1. Leave-one-participant-out validation. The held-out participant is never used for any learned preprocessing or model-selection step.](../reports/figures/fig3_lopo_schematic.png)

*Figure 1. Leave-one-participant-out validation. The held-out participant is never used for any learned preprocessing or model-selection step.*

## 6. Leakage Control and Sensitivity Analyses

Predictors use only the pre-movement interval, defined as the one-second event that ends at the execution event onset. Filtering, artefact rejection, feature extraction, imputation, scaling and feature selection are documented, and causal filtering or a guarded interval is specified so that post-onset samples cannot influence pre-onset features. Sensitivity analyses cover epoch definitions, artefact handling, valid-trial thresholds, feature families and participant influence, and the pipeline records data version, package versions, random seeds, split assignments and analysis deviations.

## 7. Results

### 7.1 Dataset inventory

All 15 participants contribute a complete set of runs, each with an event table, a channel table, a sidecar, an EEG recording and an execution-stage derivative; 127 of 128 runs also have a pre-movement derivative (Table 2). The 128 EEG recordings total 6.43 GB and none is empty. Recording length is consistent with the file sizes: bytes per recorded second equal 118,784 for the 96 runs with 29 channels and 126,976 for the 32 runs with 31 channels, which is what 4-byte samples at 1,024 Hz imply. The montage follows the extended 10/20 system with 26 EEG channels (Fp1 to O2, including FCz and CPz) for 11 participants and 28 for sub-02, 13, 14 and 15 (Figure 2); all participants additionally have VEOG, HEOG and trigger channels, and no channel is flagged bad in any channel table. The 26 channels shared by all participants form the common feature space for cross-participant models.

**Table 2. Inventory of released files by type.**

| Component | Files | Size | Note |
|---|---|---|---|
| Raw EEG (BrainVision .eeg/.vhdr/.vmrk) | 128 runs | 6.43 GB | No empty files; sizes consistent with channel count × 4 B × 1,024 Hz × duration |
| Event tables (.tsv) | 128 | — | Full structure parsed (Section 7.2) |
| Channel tables and sidecars | 128 each | — | No channel marked bad |
| Pre-movement derivative (.mat) | 127 | — | Fixed 1 s windows ending at event mark 14 |
| Movement-execution derivative (.mat) | 128 | 0.72 GB (both derivatives) | 100 Hz, EEG–Leap aligned |
| Leap hand kinematics (.tsv) | 128 | 0.70 GB | 170 Hz |
| Ball trajectory (.tsv) | 128 | — | Screen-space ball position per trial |

![Figure 2. Trials, runs and EEG channel count for each participant. Trials are shown as those with execution duration above zero and those with zero-duration execution.](../reports/figures/fig2_coverage.png)

*Figure 2. Trials, runs and EEG channel count for each participant. Trials are shown as those with execution duration above zero and those with zero-duration execution.*

### 7.2 Trial structure and accounting

Every run follows the same structure. Each trial is a premove event of 1.0 s (mean 1.0006 s, range 0.983 to 1.020 s) immediately followed, with no gap in any of the 7,029 trials, by an execution event and a hit event (Figure 3a). The execution event onset is therefore a fixed task mark that defines the end of the pre-movement window. Execution duration has a median of 2.50 s among trials with non-zero duration (interquartile range 1.97 to 3.25 s) and a right-skewed distribution bounded at 6.0 s (Figure 3b). Conditions are balanced across trials: 3,483 congruent and 3,533 incongruent trials among those with a premove event, and 3,514 left-hand and 3,515 right-hand trials. Cue colour is determined by congruency (red congruent, yellow incongruent).

Table 3 gives the trial accounting. The event tables contain 7,029 premove-anchored trials, 11 fewer than the 7,040 recorded trials in the descriptor. Of these, 6,864 have a non-zero execution duration. The 165 zero-duration executions are concentrated in one participant (137 in sub-04). Three runs contain one execution and hit pair without a preceding premove event, so the corresponding trials have no pre-movement window in the event tables. The valid-trial counts of 6,671 (descriptor) and 6,720 (README) cannot be derived from the event tables alone. The pre-movement derivatives carry a per-trial validity mask (keep_mask_1s), and the modelling stage takes its valid-trial definition from that mask and reports the resulting count against both figures.

![Figure 3. (a) Trial structure from the released event tables: a 1.0 s premove event ends at the execution event onset, and execution ends at boundary contact. (b) Distribution of execution-event durations over all 7,029 trials.](../reports/figures/fig1_trial_structure.png)

*Figure 3. (a) Trial structure from the released event tables: a 1.0 s premove event ends at the execution event onset, and execution ends at boundary contact. (b) Distribution of execution-event durations over all 7,029 trials.*

**Table 3. Trial accounting from the released event tables.**

| Quantity | Count |
|---|---|
| Event rows (premove, execution, hit) | 21,093 |
| Premove events (trial anchors) | 7,029 |
| Execution events / hit events | 7,032 / 7,032 |
| Trials with execution duration > 0 s | 6,864 |
| Trials with zero-duration execution | 165 (137 in sub-04) |
| Trials at the 6.0 s upper bound | 6 |
| Runs containing an execution event without a premove event | 3 (sub-06 run 1; sub-11 run 2; sub-12 run 3) |
| Congruent / incongruent trials | 3,483 / 3,533 |
| Left-hand / right-hand trials | 3,514 / 3,515 |

### 7.3 Participant-level outcome heterogeneity

Execution duration differs markedly between participants (Table 4, Figure 4a). Participant medians range from 1.72 s (sub-09) to 4.87 s (sub-04), and between-participant differences account for 74% of the variance among trials with non-zero duration (intraclass correlation 0.74; 0.65 without sub-04). Six participants have medians of 2.2 s or less, seven lie between 2.5 and 3.4 s, and two (sub-02 and sub-04) exceed 4.2 s. Sub-04 is distinctive: it contributes 12 runs, 137 of the 165 zero-duration executions, and the widest spread of durations, and it is therefore examined in a sensitivity analysis that excludes it.

**Table 4. Participant-level summary (execution duration in seconds; median and interquartile range over all trials with an execution event).**

| Participant | Runs | EEG ch | Trials | Duration > 0 s | Median | IQR |
|---|---|---|---|---|---|---|
| sub-01 | 8 | 26 | 320 | 315 | 3.37 | 1.02 |
| sub-02 | 8 | 28 | 480 | 472 | 4.30 | 0.97 |
| sub-03 | 8 | 26 | 480 | 479 | 2.55 | 0.74 |
| sub-04 | 12 | 26 | 478 | 341 | 4.87 | 5.43 |
| sub-05 | 12 | 26 | 480 | 479 | 3.20 | 0.68 |
| sub-06 | 8 | 26 | 477 | 469 | 3.17 | 0.93 |
| sub-07 | 8 | 26 | 480 | 479 | 2.88 | 1.09 |
| sub-08 | 8 | 26 | 480 | 480 | 2.73 | 0.62 |
| sub-09 | 8 | 26 | 480 | 477 | 1.72 | 0.67 |
| sub-10 | 8 | 26 | 480 | 480 | 1.78 | 0.40 |
| sub-11 | 8 | 26 | 476 | 476 | 1.83 | 0.43 |
| sub-12 | 8 | 26 | 479 | 478 | 2.50 | 0.62 |
| sub-13 | 8 | 28 | 480 | 480 | 1.88 | 0.55 |
| sub-14 | 8 | 28 | 480 | 480 | 2.15 | 0.45 |
| sub-15 | 8 | 28 | 479 | 479 | 2.15 | 0.45 |

### 7.4 Participant-independent outcome baselines

Table 5 and Figure 4b give leave-one-participant-out results for execution duration. The training-fold mean predictor, which uses no information about the held-out participant, has a mean fold MAE of 0.91 s (95% CI [0.67, 1.22]) and RMSE of 1.03 s on the primary set; excluding sub-04 lowers MAE to 0.77 s. Fold MAE ranges from 0.36 s to 2.55 s depending on which participant is held out, reflecting the heterogeneity in Section 7.3. A ridge regression on task covariates (congruency, target direction, hand and in-run trial position), with its penalty chosen by participant-grouped inner validation, does not improve on the mean predictor: the paired MAE gain is +0.005 s [-0.004, 0.014], and the pattern is the same when zero-duration trials are retained (set B) or sub-04 is excluded (set C). The performance any pre-movement EEG model must exceed under participant-held-out evaluation is therefore the mean-predictor error of about 0.91 s MAE (0.77 s without sub-04).

To show what participant-held-out evaluation protects against, the same primary set was split trial-wise at random (80% training, 20% test). A predictor that uses only each participant's training mean, with no neural information, reaches an MAE of 0.43 s, against 0.82 s for the global mean (Figure 4c). Participant identity alone thus removes about half of the error under a trial-wise split, so any gain an EEG model showed under such a split could reflect participant signatures rather than movement-related neural information.

![Figure 4. (a) Execution duration by participant, ordered by median (trials with non-zero duration). (b) Leave-one-participant-out MAE of the training-fold mean predictor and the task-covariate ridge for each held-out participant. (c) MAE under a trial-wise random split for the global mean and for a participant-mean predictor, neither of which uses EEG.](../reports/figures/fig4_outcome_baselines.png)

*Figure 4. (a) Execution duration by participant, ordered by median (trials with non-zero duration). (b) Leave-one-participant-out MAE of the training-fold mean predictor and the task-covariate ridge for each held-out participant. (c) MAE under a trial-wise random split for the global mean and for a participant-mean predictor, neither of which uses EEG.*

**Table 5. Leave-one-participant-out baselines for execution duration (seconds). MAE and RMSE are means over held-out participants; intervals are participant-clustered bootstrap 95% CIs.**

| Analysis set | Trials / participants | ICC | Mean predictor MAE [95% CI] | Mean predictor RMSE | Covariate ridge MAE | MAE gain, ridge − mean [95% CI] |
|---|---|---|---|---|---|---|
| A (primary): execution > 0 s | 6,864 / 15 | 0.74 | 0.91 [0.67, 1.22] | 1.03 | 0.91 | +0.005 [-0.004, 0.014] |
| B: all trials with an execution event | 7,029 / 15 | 0.45 | 0.91 [0.66, 1.23] | 1.03 | 0.90 | +0.003 [-0.004, 0.010] |
| C: set A without sub-04 | 6,523 / 14 | 0.65 | 0.77 [0.61, 0.98] | 0.90 | 0.77 | +0.001 [-0.003, 0.004] |

## 8. Discussion

The audit shows a dataset that is regular and well suited to participant-independent modelling: a uniform trial structure, balanced conditions and hands, complete event and channel tables for every run, consistent sampling rates and a 14.8 hour recording base across 15 participants. Three features of the data shape the modelling stage. First, between-participant differences dominate the available outcome, which makes participant-held-out evaluation the only defensible generalisation claim and sets a clear benchmark of roughly 0.9 s MAE for the mean predictor. Second, the uniform 26-channel subset gives a common feature space across participants, with the two additional channels in four participants available for within-montage sensitivity analyses. Third, the event-level trial accounting, with its three premove-less trials and 165 zero-duration executions, provides the explicit exclusion rules the trial-matching table requires.

The baselines also bear on interpretation. Task covariates carry no participant-independent information about execution duration, so an EEG model that beats the mean predictor in held-out participants would be doing so on neural information rather than on condition labels. Because condition and cue are linked, condition decoding from the pre-movement window is to be reported separately from kinematic prediction.

## 9. Scope and Limitations

The audit and baselines in this manuscript rest on the released event tables, channel tables, sidecars and file metadata. Execution duration is a trial-level task-completion measure; kinematic outcomes derived from the 170 Hz hand trajectories (path length, peak velocity, endpoint error) and EEG-based models are specified in Sections 5 and 6 and are evaluated against the benchmark reported here in the modelling stage. The valid-trial definition, EEG–kinematic alignment and the pre-movement filtering settings are taken from the signal derivatives at that stage. The sample of 15 participants constrains the precision and scope of participant-level generalisation claims, and predictive performance will not be interpreted as causality, conscious access, movement awareness or sense of agency.

## 10. Reproducibility Assets

The repository contains the data-audit protocol, the analysis plan, this manuscript, a BIDS inventory utility, the event-table audit and baseline scripts (src/audit_event_tables.py, src/lopo_outcome_baselines.py), the figure and manuscript builders (src/make_figures.py, src/build_manuscript.py), the LOPO-safe EEG preprocessing and ICA labelling pipeline, unit tests, a continuous-integration workflow and a bibliography. All tables and figures in this manuscript are generated from the files in reports/audit by these scripts, with a fixed random seed (20261114) for the bootstrap and the trial-wise split demonstration. The per-trial matching table, per-run audit, participant summary and file inventory are provided in reports/audit.

## Conclusion

This manuscript specifies a leakage-conscious, participant-independent framework for investigating whether pre-movement EEG predicts subsequent hand kinematics, and reports the audit and baselines on which it rests: a regular 15-participant, 128-run, 7,029-trial dataset with a common 26-channel EEG set, a participant-held-out benchmark of 0.91 s MAE for execution duration, and a quantified inflation of about a factor of two under trial-wise splitting.

## Declarations

- Data: IACKD, OpenNeuro ds006840, https://doi.org/10.18112/openneuro.ds006840.v1.0.0.
- Data descriptor: Cai M, Fu R, Wang Y, Lu B, Guo S, Xu F. Intention-Action Conflict EEG-Hand Kinematics Dataset for Unimanual Control under Congruent and Incongruent Conditions. Scientific Data. 2026;13:933. https://doi.org/10.1038/s41597-026-07146-x.
- Code: https://github.com/EkeminiThompson/movement-awareness-computational-neuroscience; archived at https://doi.org/10.5281/zenodo.24234427 (MIT licence).
- Funding: this research received no specific funding.
- Competing interests: the author declares no non-financial conflicts of interest.
- Ethics: This work is a secondary analysis of a publicly released CC0 dataset and involved no new data collection. The original study was approved by the Ethics Committee of the First Hospital of Qinhuangdao (approval number 2024G006), which approved the protocol and the public sharing of anonymised data. Written informed consent was obtained from all participants and covered anonymised storage, sharing and open publication. The data were de-identified before release (Cai et al., 2026).
- Use of AI: Claude (Anthropic; Claude Sonnet 5.5) was used to draft parts of the analysis code and manuscript text and to correct them. The author ran all analyses. No illustration was generated with AI.
