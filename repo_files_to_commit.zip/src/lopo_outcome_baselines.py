#!/usr/bin/env python3
"""Outcome-side LOPO baselines for ds006840 (no EEG).

Outcome: execution-event duration (s) from BIDS events = time from the end of the
1 s pre-movement event until boundary contact (task completion time; a coarse
movement-execution outcome, NOT a Leap-derived kinematic).

Models (all fitted on training participants only; held-out participant never used
for scaling, selection or calibration):
  M0  training-fold mean predictor
  M1  ridge on task covariates (congruency, direction, hand, in-run trial position)
"""
import sys, json
import numpy as np, pandas as pd

AUD, OUT = sys.argv[1], sys.argv[2]
rng = np.random.default_rng(20261114)
tr = pd.read_csv(f"{AUD}/trial_matching_table.csv")
rn = tr.groupby(["sub", "acq", "run"]).cumcount()
tr["pos"] = rn  # in-run order (events sorted by onset)

def features(d):
    X = pd.DataFrame({
        "incong": (d["congruency"] == "incongruent").astype(float),
        "dir_right": (d["direction"] == "right").astype(float),
        "hand_right": (d["hand"] == "right").astype(float),
        "pos": d["pos"].astype(float),
    })
    return X.values

def ridge_fit(X, y, lam):
    mu, sd = X.mean(0), X.std(0) + 1e-9
    Z = (X - mu) / sd
    b0 = y.mean()
    w = np.linalg.solve(Z.T @ Z + lam * np.eye(Z.shape[1]), Z.T @ (y - b0))
    return lambda Xn: b0 + ((Xn - mu) / sd) @ w

def lopo(d, lams=(0.1, 1, 10, 100, 1000)):
    subs = sorted(d["sub"].unique())
    res = []
    for s in subs:
        te, trn = d[d["sub"] == s], d[d["sub"] != s]
        ytr, yte = trn["exec_dur"].values, te["exec_dur"].values
        p0 = np.full(len(te), ytr.mean())
        # inner participant-grouped selection of lambda (leave-one-training-participant-out)
        inner = {}
        for lam in lams:
            errs = []
            for s2 in sorted(trn["sub"].unique()):
                a, b = trn[trn["sub"] != s2], trn[trn["sub"] == s2]
                f = ridge_fit(features(a), a["exec_dur"].values, lam)
                errs.append(np.mean(np.abs(b["exec_dur"].values - f(features(b)))))
            inner[lam] = np.mean(errs)
        lam_star = min(inner, key=inner.get)
        f = ridge_fit(features(trn), ytr, lam_star)
        p1 = f(features(te))
        res.append(dict(sub=s, n_test=len(te), lam=lam_star,
                        mae_mean=np.mean(np.abs(yte - p0)), rmse_mean=np.sqrt(np.mean((yte - p0) ** 2)),
                        mae_ridge=np.mean(np.abs(yte - p1)), rmse_ridge=np.sqrt(np.mean((yte - p1) ** 2)),
                        y_mean=yte.mean()))
    return pd.DataFrame(res)

def cluster_boot_ci(vals, B=10000):
    vals = np.asarray(vals)
    m = [rng.choice(vals, size=len(vals), replace=True).mean() for _ in range(B)]
    return float(np.percentile(m, 2.5)), float(np.percentile(m, 97.5))

def paired_boot_ci(delta, B=10000):
    return cluster_boot_ci(delta, B)

def icc_oneway(d, col):
    g = d.groupby("sub")[col]
    k = g.size().values; n = len(d); a = len(k)
    grand = d[col].mean()
    msb = (g.size() * (g.mean() - grand) ** 2).sum() / (a - 1)
    msw = ((d[col] - g.transform("mean")) ** 2).sum() / (n - a)
    k0 = (n - (k ** 2).sum() / n) / (a - 1)
    return float((msb - msw) / (msb + (k0 - 1) * msw))

# ---- analysis sets (decisions made post hoc by the analyst; protocol does not fix them) ----
base = tr[tr["has_exec"]].copy()
sets = {
    "A_primary: exec>0 s, all participants": base[base["exec_dur"] > 0],
    "B_sens: include zero-duration executions": base,
    "C_sens: A without sub-04 (bimodal, 12 runs)": base[(base["exec_dur"] > 0) & (base["sub"] != "sub-04")],
}
summary = {}
for name, d in sets.items():
    r = lopo(d)
    key = name.split(":")[0]
    r.to_csv(f"{OUT}/lopo_baselines_{key}.csv", index=False)
    delta = r["mae_mean"] - r["mae_ridge"]
    summary[name] = dict(
        n_trials=int(len(d)), n_participants=int(d["sub"].nunique()),
        icc_participant_exec_dur=icc_oneway(d, "exec_dur"),
        icc_participant_log_exec_dur=icc_oneway(d.assign(l=np.log(d["exec_dur"].clip(lower=0.05))), "l"),
        mean_fold_MAE_mean_predictor=float(r["mae_mean"].mean()),
        mean_fold_MAE_mean_predictor_CI95_cluster_boot=cluster_boot_ci(r["mae_mean"]),
        mean_fold_RMSE_mean_predictor=float(r["rmse_mean"].mean()),
        mean_fold_MAE_covariate_ridge=float(r["mae_ridge"].mean()),
        mean_fold_MAE_covariate_ridge_CI95_cluster_boot=cluster_boot_ci(r["mae_ridge"]),
        mean_fold_RMSE_covariate_ridge=float(r["rmse_ridge"].mean()),
        paired_MAE_gain_ridge_vs_mean=float(delta.mean()),
        paired_MAE_gain_CI95_cluster_boot=paired_boot_ci(delta),
        folds_where_ridge_beats_mean=int((delta > 0).sum()),
        pooled_trial_MAE_mean_predictor=float(np.average(r["mae_mean"], weights=r["n_test"])),
        fold_MAE_range_mean_predictor=[float(r["mae_mean"].min()), float(r["mae_mean"].max())],
    )

# ---- leakage demonstration: trial-wise random split vs LOPO (mean-of-nothing; participant-mean predictor) ----
d = sets["A_primary: exec>0 s, all participants"]
idx = rng.permutation(len(d)); cut = int(0.8 * len(d))
trn, te = d.iloc[idx[:cut]], d.iloc[idx[cut:]]
pm = trn.groupby("sub")["exec_dur"].mean()
pred_leaky = te["sub"].map(pm).values
leak = dict(
    trialwise_random_split_MAE_participant_mean_predictor=float(np.mean(np.abs(te["exec_dur"].values - pred_leaky))),
    trialwise_random_split_MAE_global_mean_predictor=float(np.mean(np.abs(te["exec_dur"].values - trn["exec_dur"].mean()))),
    note="Participant-identity alone (no EEG) lowers error under a trial-wise split; this is the leakage route the protocol's LOPO design closes.")
summary["leakage_demo"] = leak
json.dump(summary, open(f"{OUT}/lopo_baseline_summary.json", "w"), indent=2)
print(json.dumps(summary, indent=2))
