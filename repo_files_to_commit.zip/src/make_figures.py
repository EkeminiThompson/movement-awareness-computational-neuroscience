#!/usr/bin/env python3
"""Regenerate manuscript figures from reports/audit outputs.
usage: python src/make_figures.py reports/audit reports/figures
"""
import sys, json
import numpy as np, pandas as pd
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle

AUD, OUT = sys.argv[1], sys.argv[2]
C = dict(pre="#3B6FB6", ex="#D98A3D", hit="#2F2F2F", train="#6BA368", test="#C45B5B", g="#8A8F98")
plt.rcParams.update({"font.size": 9, "axes.spines.top": False, "axes.spines.right": False,
                     "font.family": "DejaVu Sans"})
tr = pd.read_csv(f"{AUD}/trial_matching_table.csv")
pt = pd.read_csv(f"{AUD}/participant_table.csv")
r = pd.read_csv(f"{AUD}/lopo_baselines_A_primary.csv")
S = json.load(open(f"{AUD}/lopo_baseline_summary.json"))
d = tr[tr.has_exec]; dv = d[d.exec_dur > 0]

# ---- Figure 1: trial structure + execution-duration distribution
fig, ax = plt.subplots(1, 2, figsize=(10, 3.4), dpi=200, gridspec_kw={"width_ratios": [1.15, 1]})
a = ax[0]
med, q1, q3 = dv.exec_dur.median(), dv.exec_dur.quantile(.25), dv.exec_dur.quantile(.75)
a.add_patch(Rectangle((-1, 0), 1.0, 1, fc=C["pre"], alpha=.85)); a.text(-.5, .5, "premove\n1.0 s", ha="center", va="center", color="w", fontsize=9)
a.add_patch(Rectangle((0, 0), med, 1, fc=C["ex"], alpha=.85)); a.text(med / 2, .5, f"execution\nmedian {med:.2f} s", ha="center", va="center", color="w", fontsize=9)
a.plot([med, med], [-.15, 1.15], color=C["hit"], lw=2); a.text(med, 1.22, "hit", ha="center", fontsize=9)
a.annotate("", xy=(q1, -.3), xytext=(q3, -.3), arrowprops=dict(arrowstyle="<->", color=C["g"]))
a.text((q1 + q3) / 2, -.55, f"IQR {q1:.2f}–{q3:.2f} s", ha="center", color=C["g"], fontsize=8)
a.axvline(0, color="k", lw=1, ls="--"); a.text(.06, -.85, "execution event onset (task mark)", ha="left", fontsize=8)
a.set_xlim(-1.3, 4.2); a.set_ylim(-1.1, 1.5); a.set_yticks([]); a.set_xlabel("time relative to execution event onset (s)")
a.spines["left"].set_visible(False); a.set_title("a  Trial structure from the released event tables", loc="left", fontsize=10)
b = ax[1]
b.hist(d.exec_dur, bins=np.arange(0, 6.25, .25), color=C["ex"], alpha=.9)
b.set_xlabel("execution-event duration (s)"); b.set_ylabel("trials")
b.set_title(f"b  Execution durations (n = {len(d):,})", loc="left", fontsize=10)
plt.tight_layout(); plt.savefig(f"{OUT}/fig1_trial_structure.png"); plt.close()

# ---- Figure 2: coverage by participant
fig, ax = plt.subplots(figsize=(10, 3.6), dpi=200)
x = np.arange(len(pt)); lab = [s[-2:] for s in pt["sub"]]
ax.bar(x, pt.valid, color=C["pre"], label="execution duration > 0 s")
ax.bar(x, pt.zero, bottom=pt.valid, color=C["g"], label="zero-duration execution")
for i, row in pt.iterrows():
    ax.text(i, row.trials + 8, f"{int(row.runs)} runs\n{int(row.eeg_ch)} EEG ch", ha="center", fontsize=7.5)
ax.set_xticks(x); ax.set_xticklabels(lab); ax.set_xlabel("participant"); ax.set_ylabel("trials")
ax.set_ylim(0, 600); ax.legend(frameon=False, loc="upper right", ncol=2, fontsize=8)
ax.set_title("Trials, runs and EEG channel count per participant (event tables and channel tables)", loc="left", fontsize=10)
plt.tight_layout(); plt.savefig(f"{OUT}/fig2_coverage.png"); plt.close()

# ---- Figure 3: LOPO schematic with all 15 participants
fig, ax = plt.subplots(figsize=(10, 2.6), dpi=200)
for i in range(15):
    test = (i == 14)
    ax.add_patch(Rectangle((i * 1.0, 0), .86, 1, fc=C["test"] if test else C["train"], alpha=.9))
    ax.text(i + .43, .5, f"P{i+1}\n{'Test' if test else 'Train'}", ha="center", va="center", color="w", fontsize=8)
ax.annotate("", xy=(15, -.25), xytext=(0, -.25), arrowprops=dict(arrowstyle="->", color="k"))
ax.text(7.5, -.55, "all learned steps (preprocessing, selection, tuning) fitted on training participants only", ha="center", fontsize=8.5)
ax.set_xlim(-.2, 15.2); ax.set_ylim(-.8, 1.5); ax.axis("off")
ax.set_title("Leave-one-participant-out: one of 15 outer folds shown", loc="left", fontsize=10)
plt.tight_layout(); plt.savefig(f"{OUT}/fig3_lopo_schematic.png"); plt.close()

# ---- Figure 4: outcome heterogeneity, LOPO baselines, leakage contrast
fig, ax = plt.subplots(1, 3, figsize=(12, 3.8), dpi=200, gridspec_kw={"width_ratios": [1.25, 1.25, .8]})
order = dv.groupby("sub").exec_dur.median().sort_values().index
a = ax[0]
a.boxplot([dv[dv["sub"] == s].exec_dur for s in order], showfliers=False, tick_labels=[s[-2:] for s in order],
          patch_artist=True, boxprops=dict(facecolor=C["ex"], alpha=.6), medianprops=dict(color="k"))
a.set_xlabel("participant"); a.set_ylabel("execution duration (s)")
a.set_title(f"a  Between-participant spread (ICC = {S['A_primary: exec>0 s, all participants']['icc_participant_exec_dur']:.2f})", loc="left", fontsize=9.5)
b = ax[1]; rr = r.set_index("sub").loc[order].reset_index(); xx = np.arange(len(rr)); w = .38
b.bar(xx - w/2, rr.mae_mean, w, color=C["pre"], label="training-fold mean")
b.bar(xx + w/2, rr.mae_ridge, w, color=C["train"], label="task-covariate ridge")
b.set_xticks(xx); b.set_xticklabels([s[-2:] for s in rr["sub"]]); b.set_xlabel("held-out participant"); b.set_ylabel("MAE (s)")
b.legend(frameon=False, fontsize=8); b.set_title("b  Leave-one-participant-out error", loc="left", fontsize=9.5)
c = ax[2]; lk = S["leakage_demo"]
vals = [lk["trialwise_random_split_MAE_global_mean_predictor"], lk["trialwise_random_split_MAE_participant_mean_predictor"]]
c.bar([0, 1], vals, color=[C["g"], C["test"]]); c.set_xticks([0, 1]); c.set_xticklabels(["global mean", "participant\nmean"], fontsize=8)
for i, v in enumerate(vals): c.text(i, v + .02, f"{v:.2f}", ha="center", fontsize=8.5)
c.set_ylabel("MAE (s)"); c.set_title("c  Trial-wise split, no EEG", loc="left", fontsize=9.5)
plt.tight_layout(); plt.savefig(f"{OUT}/fig4_outcome_baselines.png"); plt.close()
print("figures written")
