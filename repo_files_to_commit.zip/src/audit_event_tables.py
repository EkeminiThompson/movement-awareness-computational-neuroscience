#!/usr/bin/env python3
"""Git-level feasibility audit of OpenNeuro ds006840 (IACKD).

Works only from files present in the git mirror: BIDS event/channel/sidecar
tables, plus the byte sizes encoded in git-annex keys (SHA256E-s<bytes>--...).
Raw EEG / .mat / leap kinematics content is NOT read (not retrievable here).
"""
import json, os, re, sys, glob
import pandas as pd
import numpy as np

ROOT = sys.argv[1]
OUT = sys.argv[2]
os.makedirs(OUT, exist_ok=True)

KEY = re.compile(r"SHA256E-s(\d+)--")

def annex_size(path):
    """Return (kind, size_bytes). kind in {'real','annex','dangling-other'}."""
    if os.path.islink(path):
        m = KEY.search(os.readlink(path))
        return ("annex", int(m.group(1)) if m else None)
    return ("real", os.path.getsize(path))

# ---------- 1. file inventory (all files incl. symlinks) ----------
rows = []
for dp, dn, fn in os.walk(ROOT):
    dn[:] = [d for d in dn if d != ".git" and d != ".datalad"]
    for f in fn:
        p = os.path.join(dp, f)
        kind, sz = annex_size(p)
        rel = os.path.relpath(p, ROOT)
        sub = re.search(r"sub-(\d+)", rel)
        rows.append(dict(path=rel, sub=("sub-" + sub.group(1)) if sub else None,
                         ext=os.path.splitext(f)[1], kind=kind, bytes=sz,
                         deriv=rel.startswith("derivatives")))
inv = pd.DataFrame(rows)
inv.to_csv(f"{OUT}/file_inventory.csv", index=False)

# ---------- 2. event tables ----------
ev_rows, run_rows = [], []
for p in sorted(glob.glob(f"{ROOT}/sub-*/eeg/*_events.tsv")):
    b = os.path.basename(p)
    m = re.match(r"(sub-\d+)_task-ihc_acq-(left|right)_run-(\d+)_events.tsv", b)
    sub, acq, run = m.group(1), m.group(2), int(m.group(3))
    df = pd.read_csv(p, sep="\t", encoding="utf-8-sig")
    df["sub"], df["acq"], df["run"] = sub, acq, run
    ev_rows.append(df)
ev = pd.concat(ev_rows, ignore_index=True)
ev.to_csv(f"{OUT}/events_all.csv", index=False)

# trial reconstruction: each premove row starts a trial; next rows are execution, hit
trials = []
for (sub, acq, run), g in ev.groupby(["sub", "acq", "run"]):
    g = g.sort_values("onset").reset_index(drop=True)
    i = 0
    pat_ok = 0
    while i < len(g):
        if g.loc[i, "trial_type"] == "premove":
            t = dict(sub=sub, acq=acq, run=run, trial_idx=len(
                [x for x in trials if x["sub"] == sub and x["acq"] == acq and x["run"] == run]),
                pre_onset=g.loc[i, "onset"], pre_dur=g.loc[i, "duration"],
                congruency=g.loc[i, "congruency"], direction=g.loc[i, "direction"],
                ball_color=g.loc[i, "ball_color"], hand=g.loc[i, "hand"])
            ex = g.loc[i + 1] if i + 1 < len(g) and g.loc[i + 1, "trial_type"] == "execution" else None
            ht = g.loc[i + 2] if i + 2 < len(g) and g.loc[i + 2, "trial_type"] == "hit" else None
            t["has_exec"] = ex is not None
            t["has_hit_row"] = ht is not None
            if ex is not None:
                t["exec_onset"] = ex["onset"]; t["exec_dur"] = ex["duration"]; t["hit"] = ex["hit"]
                t["gap_pre_to_exec"] = ex["onset"] - (t["pre_onset"] + t["pre_dur"])
            if ht is not None:
                t["hit_onset"] = ht["onset"]
                t["hit_minus_exec_end"] = ht["onset"] - (ex["onset"] + ex["duration"]) if ex is not None else np.nan
            trials.append(t)
        i += 1
tr = pd.DataFrame(trials)
tr.to_csv(f"{OUT}/trial_matching_table.csv", index=False)

# ---------- 3. per-run table ----------
runs = []
for (sub, acq, run), g in ev.groupby(["sub", "acq", "run"]):
    d = tr[(tr["sub"] == sub) & (tr["acq"] == acq) & (tr["run"] == run)]
    jp = f"{ROOT}/{sub}/eeg/{sub}_task-ihc_acq-{acq}_run-{run:02d}_eeg.json"
    rec_dur = json.load(open(jp)).get("RecordingDuration") if os.path.exists(jp) else np.nan
    base = f"{ROOT}/{sub}/eeg/{sub}_task-ihc_acq-{acq}_run-{run:02d}_eeg"
    eeg_k = annex_size(base + ".eeg") if os.path.lexists(base + ".eeg") else (None, None)
    vmrk_k = annex_size(base + ".vmrk") if os.path.lexists(base + ".vmrk") else (None, None)
    last = g["onset"].max() + g.loc[g["onset"].idxmax(), "duration"]
    runs.append(dict(sub=sub, acq=acq, run=run, n_event_rows=len(g), n_trials=len(d),
                     n_exec=int(d["has_exec"].sum()), n_hit_rows=int(d["has_hit_row"].sum()),
                     n_hit1=int((d.get("hit", pd.Series(dtype=float)) == 1).sum()),
                     rec_duration_s=rec_dur, last_event_end_s=last,
                     eeg_bytes=eeg_k[1], vmrk_bytes=vmrk_k[1],
                     eeg_file_present=os.path.lexists(base + ".eeg"),
                     eeg_content_local=bool(os.path.exists(base + ".eeg"))))
rn = pd.DataFrame(runs)
rn.to_csv(f"{OUT}/per_run_audit.csv", index=False)

# ---------- 4. participant-level summary ----------
ps = rn.groupby("sub").agg(runs=("run", "count"), trials=("n_trials", "sum"),
                           hit1=("n_hit1", "sum"), eeg_gb=("eeg_bytes", lambda s: s.sum() / 1e9)).reset_index()
cond = tr.groupby(["sub", "congruency"]).size().unstack(fill_value=0)
ps = ps.merge(cond.reset_index(), on="sub")
ps.to_csv(f"{OUT}/participant_summary.csv", index=False)

# ---------- 5. checks ----------
chk = {}
chk["n_participants_with_events"] = int(ev["sub"].nunique())
chk["n_event_files"] = int(rn.shape[0])
chk["n_runs_with_eeg_symlink"] = int(rn["eeg_file_present"].sum())
chk["n_runs_with_eeg_content_local"] = int(rn["eeg_content_local"].sum())
chk["total_event_rows"] = int(len(ev))
chk["total_trials_from_premove_rows"] = int(len(tr))
chk["trials_with_execution_row"] = int(tr["has_exec"].sum())
chk["trials_with_hit_row"] = int(tr["has_hit_row"].sum())
chk["trials_hit_equals_1"] = int((tr["hit"] == 1).sum())
chk["trials_hit_equals_0"] = int((tr["hit"] == 0).sum())
chk["trial_type_counts"] = ev["trial_type"].value_counts().to_dict()
chk["premove_duration_s"] = tr["pre_dur"].describe().round(4).to_dict()
chk["gap_pre_to_exec_s"] = tr["gap_pre_to_exec"].describe().round(6).to_dict()
chk["exec_duration_s"] = tr["exec_dur"].describe().round(3).to_dict()
chk["rec_minus_last_event_s"] = (rn["rec_duration_s"] - rn["last_event_end_s"]).describe().round(2).to_dict()
chk["first_premove_onset_s_min"] = float(tr.groupby(["sub","acq","run"])["pre_onset"].min().min())
chk["congruency_counts"] = tr["congruency"].value_counts().to_dict()
chk["hand_counts"] = tr["hand"].value_counts().to_dict()
chk["ball_color_vs_congruency"] = pd.crosstab(tr["ball_color"], tr["congruency"]).to_dict()
chk["runs_per_participant"] = rn.groupby("sub")["run"].count().to_dict()
chk["trials_per_run_distribution"] = rn["n_trials"].value_counts().sort_index().to_dict()
chk["sizes_by_ext_gb"] = (inv.groupby(["deriv", "ext", "kind"])["bytes"].sum() / 1e9).round(3).reset_index().to_dict("records")
chk["n_dangling_symlinks_total"] = int(((inv["kind"] == "annex")).sum())
json.dump(chk, open(f"{OUT}/audit_checks.json", "w"), indent=2, default=str)
print(json.dumps(chk, indent=2, default=str))
